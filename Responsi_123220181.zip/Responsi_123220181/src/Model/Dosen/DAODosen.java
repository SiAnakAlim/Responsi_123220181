package Model.Dosen;

import Model.Connector;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DAODosen implements InterfaceDAODosen {

    @Override
    public void insert(ModelDosen dosen) {
        try {
            // Perintah query disimpan ke dalam variabel "query"
            String query = "INSERT INTO dosen (nama, no_hp, email) VALUES (?, ?, ?);";

            /* 
              Memasukkan nama, nim, email, password, dan angkatan dari input user ke dalam query untuk 
              mengisi bagian "?, ?, ?, ?, ?".
            */
            PreparedStatement statement;
            statement = Connector.Connect().prepareStatement(query);
            statement.setString(1, dosen.getNama());
            statement.setString(2, dosen.getNo_HP());
            statement.setString(5, dosen.getEmail());

            // Menjalankan query untuk memasukkan data dosen baru
            statement.executeUpdate();

            // Menutup koneksi untuk menghemat penggunaan memory.
            statement.close();
        } catch (SQLException e) {
            // Menampilkan pesan error ketika gagal input data.
            System.out.println("Input Failed: " + e.getLocalizedMessage());
        }
    }

    @Override
    public void update(ModelDosen dosen) {
        try {
            // Perintah query disimpan ke dalam variabel "query"
            String query = "UPDATE dosen SET nama=?, nim=?, email=?, password=?, angkatan=? WHERE id=?;";

            /* 
              Memasukkan nama, nim, email, password, dan angkatan dari input user 
              beserta id yang didapat dari data yang mau diubah ke dalam query 
              untuk mengisi bagian "?".
            */
            PreparedStatement statement;
            statement = Connector.Connect().prepareStatement(query);
            statement.setString(1, dosen.getNama());
            statement.setString(2, dosen.getNo_HP());
            statement.setString(5, dosen.getEmail());
            statement.setInt(6, dosen.getId());

            // Menjalankan query untuk mengubah data dosen yang dipilih
            statement.executeUpdate();

            // Menutup koneksi untuk menghemat penggunaan memory.
            statement.close();
        } catch (SQLException e) {
            // Menampilkan pesan error ketika gagal edit data.
            System.out.println("Update Failed! (" + e.getMessage() + ")");
        }
    }

    @Override
    public void delete(int id) {
        try {
            // Perintah query disimpan ke dalam variabel "query"
            String query = "DELETE FROM dosen WHERE id=?;";

            /* 
              Memasukkan id berdasarkan data yang mau dihapus ke dalam query 
              untuk mengisi bagian "?".
            */
            PreparedStatement statement;
            statement = Connector.Connect().prepareStatement(query);
            statement.setInt(1, id);

            // Menjalankan query untuk menghapus data dosen yang dipilih
            statement.executeUpdate();

            // Menutup koneksi untuk menghemat penggunaan memory.
            statement.close();
        } catch (SQLException e) {
            // Menampilkan pesan error ketika gagal hapus data.
            System.out.println("Delete Failed: " + e.getLocalizedMessage());
        }
    }

    @Override
    public List<ModelDosen> getAll() {
        List<ModelDosen> listDosen = new ArrayList<>();

        try {
            // Membuat objek statement yang digunakan untuk melakukan query.
            Statement statement = Connector.Connect().createStatement();

            /* 
                Menyimpan query database ke dalam varibel "query".
                Dalam hal ini, kita akan mengambil seluruh data dosen pada tabel "dosen".
            */
            String query = "SELECT * FROM dosen;";

             // Mengeksekusi query dan menyimpannya ke dalam variabel "resultSet".
            ResultSet resultSet = statement.executeQuery(query);

            /* 
                Karena hasil query memiliki tipe data List, supaya dapat mencetak semua data dosen,
                Kita perlu melakukan looping (perulangan) untuk mencetak tiap-tiap elemen.
            */
            while (resultSet.next()) {
                // Membuat sebuah objek "Dosen" untuk menyimpan data tiap-tiap dosen
                ModelDosen dosen = new ModelDosen();

                // Memasukkan hasil query ke objek dosen
                dosen.setId(resultSet.getInt("id"));
                dosen.setNama(resultSet.getString("nama"));
                dosen.setNo_HP(resultSet.getString("nohp"));
                dosen.setEmail(resultSet.getString("email"));

                /* 
                  Menambahkan dosen ke dalam daftar dosen.
                  Daftar dosen disimpan ke dalam variabel "listDosen"
                  yang memiliki tipe data List.
                */
                listDosen.add(dosen);
            }

            // Menutup koneksi untuk menghemat penggunaan memory.
            statement.close();
        } catch (SQLException e) {
            // Menampilkan pesan error ketika gagal mengambil data.
            System.out.println("Error: " + e.getLocalizedMessage());
        }
        return listDosen;
    }
    @Override
    public List<ModelDosen> getID(String id) {
    List<ModelDosen> filteredDosen = new ArrayList<>();

    try {
        // Membuat objek statement yang digunakan untuk melakukan query.
        PreparedStatement statement = Connector.Connect().prepareStatement("SELECT * FROM dosen WHERE nim = ?;");
        statement.setString(1, id);

        // Mengeksekusi query dan menyimpannya ke dalam variabel "resultSet".
        ResultSet resultSet = statement.executeQuery();

        /* 
            Karena hasil query memiliki tipe data List, supaya dapat mencetak semua data dosen,
            kita perlu melakukan looping (perulangan) untuk mencetak tiap-tiap elemen.
        */
        while (resultSet.next()) {
            // Membuat sebuah objek "Dosen" untuk menyimpan data tiap-tiap dosen
            ModelDosen dosen = new ModelDosen();

            // Memasukkan hasil query ke objek dosen
            dosen.setId(resultSet.getInt("id"));
            dosen.setNama(resultSet.getString("nama"));
            dosen.setNo_HP(resultSet.getString("noHP"));
            dosen.setEmail(resultSet.getString("email"));

            /* 
              Menambahkan dosen ke dalam daftar dosen.
              Daftar dosen disimpan ke dalam variabel "filteredDosen"
              yang memiliki tipe data List.
            */
            filteredDosen.add(dosen);
        }

        // Menutup koneksi untuk menghemat penggunaan memory.
        statement.close();
    } catch (SQLException e) {
        // Menampilkan pesan error ketika gagal mengambil data.
        System.out.println("Error: " + e.getLocalizedMessage());
    }
    return filteredDosen;
}

}
