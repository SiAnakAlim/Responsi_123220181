package Model.Dosen;


import java.util.List;

public interface InterfaceDAODosen {
    // Method untuk memasukkan suatu data mahasiswa
    public void insert(ModelDosen dosen);
    
    // Method untuk mengupdate (mengedit) suatu data mahasiswa
    public void update(ModelDosen mahasiswa);
    
    // Method untuk menghapus suatu data mahasiswa
    public void delete(int id);
    
   // Method untuk mengambil data mahasiswa
    public List<ModelDosen> getAll();
    
    // Method untuk mencari mahasiswa berdasarkan NIM
    public List<ModelDosen> getID(String id);
}
