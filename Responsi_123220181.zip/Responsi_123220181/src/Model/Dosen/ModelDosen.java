package Model.Dosen;

public class ModelDosen {
    private Integer id;
    private String nama;
    private String no_hp;
    private String email;

    // Getter dan Setter untuk id
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    // Getter dan Setter untuk nama
    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }
     // Getter dan Setter untuk nama
    public String getNo_HP() {
        return no_hp;
    }

    public void setNo_HP(String no_hp) {
        this.no_hp = no_hp;
    }
    // Getter dan Setter untuk nama
    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}
