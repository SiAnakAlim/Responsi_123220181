package Controller;

import Model.Mahasiswa.*;
import View.Mahasiswa.*;
import java.util.List;
import javax.swing.JOptionPane;

public class ControllerMahasiswa {

    ViewData halamanTable;
    InputData halamanInput;
    EditData halamanEdit;

    InterfaceDAOMahasiswa daoMahasiswa;

    List<ModelMahasiswa> daftarMahasiswa;

    public ControllerMahasiswa(ViewData halamanTable) {
        this.halamanTable = halamanTable;
        this.daoMahasiswa = new DAOMahasiswa();
    }

    public ControllerMahasiswa(InputData halamanInput) {
        this.halamanInput = halamanInput;
        this.daoMahasiswa = new DAOMahasiswa();
    }

    public ControllerMahasiswa(EditData halamanEdit) {
        this.halamanEdit = halamanEdit;
        this.daoMahasiswa = new DAOMahasiswa();
    }

    public void showAllMahasiswa() {
        daftarMahasiswa = daoMahasiswa.getAll();
        ModelTable table = new ModelTable(daftarMahasiswa);
        halamanTable.getTableMahasiswa().setModel(table);
    }

    public void insertMahasiswa() {
    try {
        ModelMahasiswa mahasiswaBaru = new ModelMahasiswa();
        String nama = halamanInput.getInputNama();
        String nim = halamanInput.getInputNIM();
        String angkatan = halamanInput.getInputAngkatan(); // Tambahkan pengambilan angkatan
        if ("".equals(nama) || "".equals(nim) || "".equals(angkatan)) { // Periksa jika ada kolom yang kosong
            throw new Exception("Nama, NIM, atau Angkatan tidak boleh kosong!");
        }
        mahasiswaBaru.setNama(nama);
        mahasiswaBaru.setNim(nim);
        mahasiswaBaru.setAngkatan(angkatan); // Set angkatan
        daoMahasiswa.insert(mahasiswaBaru); // Memasukkan data mahasiswa baru ke database
        JOptionPane.showMessageDialog(null, "Mahasiswa baru berhasil ditambahkan.");
        halamanInput.dispose();
        new ViewData().refreshTable(); // Perbarui tabel setelah memasukkan data
    } catch (Exception e) {
        JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
    }
}


    
    public void editMahasiswa(int id) {
        try {
            ModelMahasiswa mahasiswaYangMauDiedit = new ModelMahasiswa();
            String nama = halamanEdit.getInputNama();
            String nim = halamanEdit.getInputNIM();
            if ("".equals(nama) || "".equals(nim)) {
                throw new Exception("Nama atau NIM tidak boleh kosong!");
            }
            mahasiswaYangMauDiedit.setId(id);
            mahasiswaYangMauDiedit.setNama(nama);
            mahasiswaYangMauDiedit.setNim(nim);
            daoMahasiswa.update(mahasiswaYangMauDiedit);
            JOptionPane.showMessageDialog(null, "Data mahasiswa berhasil diubah.");
            halamanEdit.dispose();
            new ViewData();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
        }
    }

    public void deleteMahasiswa(Integer id) {
        try{
            daoMahasiswa.delete(id);
            JOptionPane.showMessageDialog(null,"Mahasiswa dengan ID" + id + "Berhasil dihapus");
           showAllMahasiswa();
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, "Error" + e.getMessage());
        }
    }
   public void searchMahasiswaByNIM(String nim){
       try{
           if(!nim.isEmpty()){
               List<ModelMahasiswa> filteredMahasiswa = daoMahasiswa.getNim(nim);
               if(!filteredMahasiswa.isEmpty()){
                   ModelTable table = new ModelTable(filteredMahasiswa);
                   halamanTable.getTableMahasiswa().setModel(table);
               }else{
                   JOptionPane.showMessageDialog(null,"Data tidak ditemukan" );
               }
           }else{
               JOptionPane.showMessageDialog(null, "Silahkan masukkan NIM untuk pencarian");
               
           }
                   
       }
       catch (Exception e){
           JOptionPane.showMessageDialog(null, "Error:" + e.getMessage());
       }
   }
}
