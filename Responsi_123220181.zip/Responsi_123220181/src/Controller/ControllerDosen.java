/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import View.Dosen.EditDosen;
import View.Dosen.EditDosen;
import View.Dosen.InputData;
import View.Dosen.ViewDosen;

/**
 *
 * @author PC PRAKTIKUM
 */
public class ControllerDosen {

    public ControllerDosen(EditDosen aThis) {
    }
    ViewDosen halamanView;
    InputData halamanInput;
    EditDosen halamanEdit;

    public void EditDosen(Integer id) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
}
