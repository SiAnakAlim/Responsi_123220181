package Main;

import View.Home;

public class Main {

    public static void main(String[] args) {
    
    new Home();
    }
}
