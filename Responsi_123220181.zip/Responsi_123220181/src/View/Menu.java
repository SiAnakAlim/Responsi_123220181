package View;

import View.Dosen.ViewDosen;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import View.Mahasiswa.ViewData; // Import class ViewData

public class Menu extends JFrame {

    public Menu(String username) {
        // Set title of the frame
        setTitle("Menu");

        // Set default close operation
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Set layout manager
        setLayout(new BorderLayout());

        // Create components
        JLabel welcomeLabel = new JLabel("Selamat Datang, " + username + "!", JLabel.CENTER);
        JLabel instructionLabel = new JLabel("Silahkan pilih untuk melanjutkan", JLabel.CENTER);
        JButton mahasiswaButton = new JButton("Mahasiswa");
        JButton dosenButton = new JButton("Dosen");
        JButton logoutButton = new JButton("Logout");

        // Style the components
        welcomeLabel.setFont(new Font("Arial", Font.BOLD, 24));
        instructionLabel.setFont(new Font("Arial", Font.PLAIN, 18));
        mahasiswaButton.setFont(new Font("Arial", Font.PLAIN, 16));
        dosenButton.setFont(new Font("Arial", Font.PLAIN, 16));
        logoutButton.setFont(new Font("Arial", Font.PLAIN, 16));

        // Panel for buttons
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new GridBagLayout());
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(20, 50, 20, 50));

        // Add buttons to buttonPanel with same size
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = GridBagConstraints.RELATIVE;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1.0;
        gbc.insets = new Insets(10, 0, 10, 0);
        buttonPanel.add(mahasiswaButton, gbc);
        buttonPanel.add(dosenButton, gbc);
        buttonPanel.add(logoutButton, gbc);

        // Add components to the frame
        add(welcomeLabel, BorderLayout.NORTH);
        add(instructionLabel, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);

        // Add action listener for mahasiswaButton
        mahasiswaButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose(); // Close the current frame
                new ViewData(); // Open the ViewData frame
            }
        });
         dosenButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose(); // Close the current frame
                new ViewDosen(); // Open the ViewData frame
            }
        });

        // Add action listener for logout button
        logoutButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0); // Exit the application
            }
        });

        // Adjust the frame size and set it visible
        setSize(400, 300);
        setLocationRelativeTo(null);
        setVisible(true);
    }

}
