package View.Dosen;

import Controller.ControllerDosen;
import Model.Dosen.ModelDosen;
import Model.Dosen.ModelDosen;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

public class EditDosen extends JFrame {
    // Membuat sebuah instance bernama controller dari class "ControllerMahasiswa".
    ControllerDosen controller;
    
    JLabel header = new JLabel("Edit Mahasiswa");
    JLabel labelInputNama = new JLabel("Nama");
    JLabel labelInputNO = new JLabel("NO-HP");
    JLabel labelInputEmail = new JLabel("Email");
    JTextField inputNama = new JTextField();
    JTextField inputNO = new JTextField();
    JTextField inputEmail = new JTextField();
    JButton tombolEdit = new JButton("Edit Dosen");
    JButton tombolKembali = new JButton("Kembali");

    public EditDosen(ModelDosen dosen) {
        setTitle("Edit Dosen");
        setVisible(true);
        setSize(480, 300); // Perbesar frame untuk menampung input angkatan
        setLayout(null);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        add(header);
        add(labelInputNama);
        add(labelInputNO);
        add(labelInputEmail); // Tambahkan label untuk angkatan
        add(inputNama);
        add(inputNO);
        add(inputEmail); // Tambahkan field input untuk angkatan
        add(tombolEdit);
        add(tombolKembali);

        header.setBounds(20, 8, 440, 24);
        labelInputNama.setBounds(20, 32, 440, 24);
        inputNama.setBounds(18, 56, 440, 36);
        labelInputNO.setBounds(20, 96, 440, 24);
        inputNO.setBounds(18, 120, 440, 36);
        labelInputEmail.setBounds(20, 160, 440, 24); // Atur posisi label angkatan
        inputEmail.setBounds(18, 184, 440, 36); // Atur posisi input angkatan
        tombolKembali.setBounds(20, 228, 215, 40);
        tombolEdit.setBounds(240, 228, 215, 40);
        
        // Masukkan nama, nim, dan angkatan yang didapat dari halaman sebelumnya
        inputNama.setText(dosen.getNama());
        inputNO.setText(dosen.getNo_HP());
        inputEmail.setText(String.valueOf(dosen.getEmail())); // Ubah angkatan ke string

        controller = new ControllerDosen(this);

        tombolKembali.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                new ViewDosen();
            }
        });

        tombolEdit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                controller.EditDosen(dosen.getId());
                new ViewDosen().refreshTable();
            }
        });
    }
    
    public String getInputNama() {
        return inputNama.getText();
    }
    
    public String getInputNO() {
        return inputNO.getText();
    }

    public int getInputEmail() {
        // Mengonversi nilai angkatan dari string ke integer
        return Integer.parseInt(inputEmail.getText());
    }
}
