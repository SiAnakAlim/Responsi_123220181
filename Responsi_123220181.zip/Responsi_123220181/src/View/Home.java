package View;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Home extends JFrame {

    public Home() {
        // Set title of the frame
        setTitle("Selamat Datang");

        // Set default close operation
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Set layout manager
        setLayout(new BorderLayout());

        // Create components
        JLabel welcomeLabel = new JLabel("Selamat Datang", JLabel.CENTER);
        JLabel instructionLabel = new JLabel("Silahkan masuk untuk melanjutkan", JLabel.CENTER);
        JLabel usernameLabel = new JLabel("Username");
        JTextField usernameField = new JTextField(20);
        JLabel passwordLabel = new JLabel("Password");
        JPasswordField passwordField = new JPasswordField(20);
        JButton loginButton = new JButton("Login");

        // Style the components
        welcomeLabel.setFont(new Font("Arial", Font.BOLD, 24));
        instructionLabel.setFont(new Font("Arial", Font.PLAIN, 18));
        usernameLabel.setFont(new Font("Arial", Font.BOLD, 16));
        passwordLabel.setFont(new Font("Arial", Font.BOLD, 16));
        loginButton.setFont(new Font("Arial", Font.PLAIN, 16));

        // Panel for inputs
        JPanel inputPanel = new JPanel();
        inputPanel.setLayout(new BoxLayout(inputPanel, BoxLayout.Y_AXIS));
        inputPanel.setBorder(BorderFactory.createEmptyBorder(20, 50, 20, 50));

        usernameLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        usernameField.setAlignmentX(Component.CENTER_ALIGNMENT);
        passwordLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        passwordField.setAlignmentX(Component.CENTER_ALIGNMENT);

        inputPanel.add(usernameLabel);
        inputPanel.add(Box.createRigidArea(new Dimension(0, 5)));
        inputPanel.add(usernameField);
        inputPanel.add(Box.createRigidArea(new Dimension(0, 20)));
        inputPanel.add(passwordLabel);
        inputPanel.add(Box.createRigidArea(new Dimension(0, 5)));
        inputPanel.add(passwordField);

        // Panel for login button
        JPanel buttonPanel = new JPanel();
        buttonPanel.add(loginButton);

        // Add components to the frame
        add(welcomeLabel, BorderLayout.NORTH);
        add(instructionLabel, BorderLayout.CENTER);
        add(inputPanel, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);

        // Add action listener for login button
        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String username = usernameField.getText();
                if (!username.isEmpty()) {
                    new Menu(username);
                    dispose(); // Close the current frame
                } else {
                    JOptionPane.showMessageDialog(Home.this, "Username tidak boleh kosong", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        // Adjust the frame size and set it visible
        setSize(400, 300);
        setLocationRelativeTo(null);
        setVisible(true);
    }
}
